package com.scorenexus.ui;

import com.scorenexus.db.DatabaseManager;
import com.scorenexus.model.MatchData;
import com.scorenexus.model.MatchState;
import com.scorenexus.model.PlayerStats;
import com.scorenexus.util.CSVExporter;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

/**
 * The main panel for scoring a cricket match.
 * Handles all match logic, UI updates, and database calls.
 */
public class CricketPanel extends JPanel {
    
    // Match State
    private int score = 0, wickets = 0, totalBalls = 0, target = 0;
    private boolean isFirstInnings = true;
    private String battingTeam, bowlingTeam;
    private final MatchData matchData;
    private ArrayList<String> highlights = new ArrayList<>();
    private Map<String, PlayerStats> playerStatsMap = new HashMap<>();
    private Stack<MatchState> historyStack = new Stack<>(); // For Undo
    
    // Database
    private final DatabaseManager dbManager;
    private final int matchId; // ID for this match in the DB
    
    // UI Components
    private JLabel scoreLabel, oversLabel, runRateLabel, targetLabel, matchDetailsLabel;
    private JTextArea highlightsTextArea;
    private JButton[] runButtons = new JButton[7]; // 0-6
    private JButton wideButton, noBallButton, wicketButton, legByeButton, byesButton, undoButton;
    private JComboBox<String> strikerComboBox, nonStrikerComboBox, bowlerComboBox;
    private JLabel batsman1StatsLabel, batsman2StatsLabel, bowlerStatsLabel;
    private JPanel controlsPanel; 
    
    // Formatting
    private static final DecimalFormat df = new DecimalFormat("0.00");
    private static final DecimalFormat srDF = new DecimalFormat("0.0"); // For Strike Rate

    public CricketPanel(MatchData data, DatabaseManager dbManager) {
        this.matchData = data;
        this.dbManager = dbManager;
        
        initializeTeams();
        initializePlayerStats();
        
        // --- Create Match in DB ---
        this.matchId = dbManager.createNewMatch(data);
        if (this.matchId == -1) {
            JOptionPane.showMessageDialog(this, "Failed to create match in database. Aborting.", 
                    "Database Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        setLayout(new BorderLayout(15, 15));
        setBackground(AppColors.BACKGROUND_LIGHT);
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        add(createTopPanel(), BorderLayout.NORTH);
        add(createCenterPanel(), BorderLayout.CENTER);
        
        controlsPanel = createControlsPanel(); 
        add(controlsPanel, BorderLayout.SOUTH);
        
        add(createRightPanel(), BorderLayout.EAST);
        
        addHighlight("Toss won by " + data.tossWinner() + ", who chose to " + data.tossDecision() + ".");
        addHighlight("Match Started: " + battingTeam + " is batting.");
        updateScoreboard();
        updatePlayerStatsDisplay();
    }

    private JPanel createTopPanel() {
        JPanel topPanel = new JPanel(new BorderLayout(20, 10)); // Added gap
        topPanel.setBackground(AppColors.PANEL_BG);
        
        TitledBorder border = BorderFactory.createTitledBorder("Live Match");
        border.setTitleColor(AppColors.BOLD_TEXT);
        border.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        topPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AppColors.BORDER_COLOR),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // --- Add Logo ---
        ImageIcon logoIcon = new ImageIcon("resources/app_logo.png");
        Image scaledImg = logoIcon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledImg));
        logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
        topPanel.add(logoLabel, BorderLayout.WEST);

        // --- Match Details ---
        String detailsText = String.format("%s vs %s | %s (%d Overs) | %s",
            matchData.teamAName(), matchData.teamBName(), matchData.matchType(),
            matchData.totalOvers(), matchData.venue());
        matchDetailsLabel = new JLabel(detailsText, SwingConstants.CENTER);
        matchDetailsLabel.setFont(new Font("SansSerif", Font.ITALIC, 16));
        
        JPanel scoresPanel = new JPanel(new GridLayout(1, 4, 15, 15));
        scoresPanel.setBackground(AppColors.PANEL_BG);
        
        scoreLabel = createStyledScoreLabel("0 / 0", 48, AppColors.BOLD_TEXT);
        oversLabel = createStyledScoreLabel("Overs: 0.0", 24, Color.GRAY);
        runRateLabel = createStyledScoreLabel("RR: 0.00", 24, Color.GRAY);
        targetLabel = createStyledScoreLabel("Target: -", 24, new Color(20, 100, 20));

        scoresPanel.add(oversLabel);
        scoresPanel.add(scoreLabel);
        scoresPanel.add(runRateLabel);
        scoresPanel.add(targetLabel);
        
        topPanel.add(matchDetailsLabel, BorderLayout.NORTH);
        topPanel.add(scoresPanel, BorderLayout.CENTER);
        return topPanel;
    }
    
    private JLabel createStyledScoreLabel(String text, int size, Color color) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Serif", Font.BOLD, size));
        label.setForeground(color);
        return label;
    }

    private JPanel createRightPanel() {
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(AppColors.BACKGROUND_LIGHT);
        rightPanel.setOpaque(false);

        // --- Player Controls ---
        JPanel playerControlPanel = new JPanel();
        playerControlPanel.setLayout(new BoxLayout(playerControlPanel, BoxLayout.Y_AXIS));
        playerControlPanel.setBackground(AppColors.PANEL_BG);
        TitledBorder pcBorder = BorderFactory.createTitledBorder("Player Controls");
        pcBorder.setTitleColor(AppColors.BOLD_TEXT);
        pcBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        playerControlPanel.setBorder(BorderFactory.createCompoundBorder(
             BorderFactory.createLineBorder(AppColors.BORDER_COLOR),
             BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        
        ArrayList<String> battingPlayers = battingTeam.equals(matchData.teamAName()) ? matchData.teamAPlayers() : matchData.teamBPlayers();
        ArrayList<String> bowlingPlayers = bowlingTeam.equals(matchData.teamAName()) ? matchData.teamAPlayers() : matchData.teamBPlayers();
        
        strikerComboBox = new JComboBox<>(battingPlayers.toArray(new String[0]));
        nonStrikerComboBox = new JComboBox<>(battingPlayers.toArray(new String[0]));
        bowlerComboBox = new JComboBox<>(bowlingPlayers.toArray(new String[0]));
        
        strikerComboBox.setBackground(new Color(255, 255, 220)); // Light yellow
        
        if (battingPlayers.size() > 1) {
            strikerComboBox.setSelectedIndex(0);
            nonStrikerComboBox.setSelectedIndex(1);
        }
        
        playerControlPanel.add(new JLabel("Striker:")); 
        playerControlPanel.add(strikerComboBox);
        playerControlPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        playerControlPanel.add(new JLabel("Non-Striker:")); 
        playerControlPanel.add(nonStrikerComboBox);
        playerControlPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        playerControlPanel.add(new JLabel("Bowler:")); 
        playerControlPanel.add(bowlerComboBox);
        
        strikerComboBox.addActionListener(e -> updatePlayerStatsDisplay());
        nonStrikerComboBox.addActionListener(e -> updatePlayerStatsDisplay());
        bowlerComboBox.addActionListener(e -> updatePlayerStatsDisplay());

        // --- Management Panel ---
        JPanel managementPanel = new JPanel();
        managementPanel.setLayout(new BoxLayout(managementPanel, BoxLayout.Y_AXIS));
        managementPanel.setBackground(AppColors.PANEL_BG);
        TitledBorder mBorder = BorderFactory.createTitledBorder("Management");
        mBorder.setTitleColor(AppColors.BOLD_TEXT);
        mBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        managementPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AppColors.BORDER_COLOR),
            BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));

        JButton exportCSV = new JButton("Export Highlights (.csv)");
        JButton endInningsButton = new JButton("End/Declare Innings");
        undoButton = new JButton("Undo Last Action (Z)");
        
        styleManagementButton(exportCSV, new Color(100, 100, 100)); // Darker Gray
        styleManagementButton(undoButton, new Color(255, 165, 0)); // Orange
        styleManagementButton(endInningsButton, AppColors.SECONDARY_BUTTON_BG.darker()); // Dark Blue
        
        exportCSV.addActionListener(e -> CSVExporter.exportHighlights(this, highlights));
        undoButton.addActionListener(e -> undoLastAction());
        endInningsButton.addActionListener(e -> manuallyEndInnings());

        managementPanel.add(exportCSV);
        managementPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        managementPanel.add(undoButton);
        managementPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        managementPanel.add(endInningsButton);
        
        rightPanel.add(playerControlPanel);
        rightPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        rightPanel.add(managementPanel);
        rightPanel.add(Box.createVerticalGlue()); // Pushes panels to the top
        return rightPanel;
    }
    
    private void styleManagementButton(JButton button, Color bgColor) {
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        button.setMaximumSize(new Dimension(Integer.MAX_VALUE, button.getPreferredSize().height));
    }

    private void manuallyEndInnings() {
        if (isFirstInnings) {
            int option = JOptionPane.showConfirmDialog(this, "Are you sure you want to end the first innings?", 
                    "Confirm Innings End", JOptionPane.YES_NO_OPTION);
            if (option == JOptionPane.YES_OPTION) {
                addHighlight("---------- INNINGS DECLARED/ENDED MANUALLY ----------");
                startSecondInnings();
            }
        } else {
            endMatch(false); // Force end
        }
    }
    
    private void endMatch(boolean isNormalEnd) {
        disableControls();
        String result;
        
        if (score >= target) {
            result = battingTeam + " won by " + (10 - wickets) + " wickets.";
        } else if (score == target - 1 && isNormalEnd) {
            result = "Match Tied!";
        } else {
            result = bowlingTeam + " won by " + (target - 1 - score) + " runs.";
        }
        
        addHighlight("---------- MATCH OVER ----------");
        addHighlight(result);
        
        // --- Persist Result ---
        dbManager.endMatch(matchId, result);
        
        JOptionPane.showMessageDialog(this, result, "Match Result", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void addRuns(int runs, boolean countsForBatsman) {
        saveStateForUndo();
        score += runs;
        totalBalls++;
        
        String strikerName = (String) strikerComboBox.getSelectedItem();
        String bowlerName = (String) bowlerComboBox.getSelectedItem();
        PlayerStats striker = playerStatsMap.get(strikerName);
        PlayerStats bowler = playerStatsMap.get(bowlerName);
        
        if (countsForBatsman) {
            striker.runsScored += runs;
            striker.ballsFaced++;
            if (runs == 4) striker.fours++;
            if (runs == 6) striker.sixes++;
        }
        bowler.runsConceded += runs;
        bowler.ballsBowled++;
        
        String runText = runs == 0 ? "DOT BALL" : runs + (runs == 1 ? " run" : " runs");
        if (runs == 4) runText = "FOUR! 4 runs";
        if (runs == 6) runText = "SIX! 6 runs";
        
        String event = String.format("%s. Score is %d/%d", runText, score, wickets);
        addHighlight(event);
        
        // --- Persist Stats ---
        dbManager.updatePlayerStats(matchId, strikerName, striker);
        dbManager.updatePlayerStats(matchId, bowlerName, bowler);

        updateAllDisplays();

        // Swap batsmen on 1, 3 runs
        if (runs == 1 || runs == 3) {
            swapBatsmen();
        }
        
        // Swap batsmen at end of over
        if (totalBalls % 6 == 0) {
            swapBatsmen();
            addHighlight("--- End of Over " + (totalBalls / 6) + " ---");
        }
    }
    
    private void startSecondInnings() {
        isFirstInnings = false;
        target = score + 1;
        addHighlight("---------- INNINGS BREAK ----------");
        addHighlight(battingTeam + " scored " + score + "/" + wickets + ". Target is " + target);
        
        score = 0;
        wickets = 0;
        totalBalls = 0;
        
        String tempTeam = battingTeam;
        battingTeam = bowlingTeam;
        bowlingTeam = tempTeam;
        
        addHighlight(battingTeam + " is now batting, chasing " + target + ".");
        targetLabel.setText("Target: " + target);
        targetLabel.setForeground(new Color(20, 100, 20)); 
        
        ArrayList<String> newBatting = battingTeam.equals(matchData.teamAName()) ? matchData.teamAPlayers() : matchData.teamBPlayers();
        ArrayList<String> newBowling = bowlingTeam.equals(matchData.teamAName()) ? matchData.teamAPlayers() : matchData.teamBPlayers();
        strikerComboBox.setModel(new DefaultComboBoxModel<>(newBatting.toArray(new String[0])));
        nonStrikerComboBox.setModel(new DefaultComboBoxModel<>(newBatting.toArray(new String[0])));
        bowlerComboBox.setModel(new DefaultComboBoxModel<>(newBowling.toArray(new String[0])));
        if (newBatting.size() > 1) {
            strikerComboBox.setSelectedIndex(0);
            nonStrikerComboBox.setSelectedIndex(1);
        }
        bowlerComboBox.setSelectedIndex(0);
        
        enableControls();
        historyStack.clear(); // Cannot undo past innings break
        undoButton.setEnabled(false);
    }
    
    private void checkForInningsEnd() {
        boolean oversFinished = (totalBalls / 6) >= matchData.totalOvers() && totalBalls % 6 == 0;
        boolean allOut = wickets >= 10;
        
        if (isFirstInnings && (allOut || oversFinished)) {
            startSecondInnings();
        } else if (!isFirstInnings) {
            boolean targetReached = score >= target;
            if (targetReached || allOut || oversFinished) {
                 endMatch(true); // Normal end
            }
        }
    }
    
    private void updateAllDisplays() {
        updateScoreboard();
        updatePlayerStatsDisplay();
        checkForInningsEnd();
    }
    
    private JPanel createCenterPanel() {
        JPanel centerPanel = new JPanel(new BorderLayout(15, 15));
        centerPanel.setBackground(AppColors.BACKGROUND_LIGHT);
        centerPanel.setOpaque(false);
        
        JPanel statsPanel = new JPanel(new GridBagLayout());
        statsPanel.setBackground(AppColors.PANEL_BG);
        statsPanel.setBorder(BorderFactory.createLineBorder(AppColors.BORDER_COLOR));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(0, 0, 0, 0);
        
        // Batsman Stats Panel
        JPanel batsmanStatsPanel = new JPanel(new GridLayout(2, 1, 0, 10));
        batsmanStatsPanel.setBackground(AppColors.PANEL_BG);
        TitledBorder bBorder = BorderFactory.createTitledBorder("Batsman Stats (Batting: " + battingTeam + ")");
        bBorder.setTitleColor(AppColors.BOLD_TEXT);
        bBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        batsmanStatsPanel.setBorder(BorderFactory.createCompoundBorder(
            bBorder,
            BorderFactory.createEmptyBorder(5, 10, 10, 10)
        ));
        
        batsman1StatsLabel = new JLabel("Striker: N/A");
        batsman1StatsLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        batsman2StatsLabel = new JLabel("Non-Striker: N/A");
        batsman2StatsLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        batsmanStatsPanel.add(batsman1StatsLabel);
        batsmanStatsPanel.add(batsman2StatsLabel);
        
        // Bowler Stats Panel
        JPanel bowlerStatsPanel = new JPanel(new GridLayout(1, 1));
        bowlerStatsPanel.setBackground(AppColors.PANEL_BG);
        TitledBorder oBorder = BorderFactory.createTitledBorder("Bowler Stats (Bowling: " + bowlingTeam + ")");
        oBorder.setTitleColor(AppColors.BOLD_TEXT);
        oBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        bowlerStatsPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 1, 0, 0, AppColors.BORDER_COLOR), // Left border
            BorderFactory.createCompoundBorder(
                oBorder,
                BorderFactory.createEmptyBorder(5, 10, 10, 10)
            )
        ));
        bowlerStatsLabel = new JLabel("Bowler: N/A");
        bowlerStatsLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
        bowlerStatsPanel.add(bowlerStatsLabel);
        
        gbc.gridx = 0; gbc.weightx = 0.6; gbc.weighty = 1.0; 
        statsPanel.add(batsmanStatsPanel, gbc);
        
        gbc.gridx = 1; gbc.weightx = 0.4;
        statsPanel.add(bowlerStatsPanel, gbc);
        
        // Highlights Area
        highlightsTextArea = new JTextArea(10, 40);
        highlightsTextArea.setEditable(false);
        highlightsTextArea.setFont(new Font("Monospaced", Font.PLAIN, 13));
        highlightsTextArea.setMargin(new Insets(5, 5, 5, 5));
        JScrollPane highlightsScrollPane = new JScrollPane(highlightsTextArea);
        TitledBorder hBorder = BorderFactory.createTitledBorder("Ball-by-Ball Highlights");
        hBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        highlightsScrollPane.setBorder(hBorder);
        
        centerPanel.add(statsPanel, BorderLayout.NORTH);
        centerPanel.add(highlightsScrollPane, BorderLayout.CENTER);
        return centerPanel;
    }
    
    private JPanel createControlsPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(AppColors.PANEL_BG);
        TitledBorder cBorder = BorderFactory.createTitledBorder("Scoring Controls");
        cBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        panel.setBorder(cBorder);
        
        // Runs Panel
        JPanel runsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        runsPanel.setBackground(AppColors.PANEL_BG);
        for (int i = 0; i <= 6; i++) {
            if (i == 5) continue; // Skip 5-run button

            runButtons[i] = new JButton(String.valueOf(i));
            runButtons[i].setToolTipText(i + " Runs");
            runButtons[i].setFont(new Font("SansSerif", Font.BOLD, 18));
            Color bg = (i == 4 || i == 6) ? AppColors.PRIMARY_BUTTON_BG.brighter() : new Color(220, 220, 220);
            Color fg = (i == 4 || i == 6) ? Color.WHITE : Color.BLACK;
            runButtons[i].setBackground(bg);
            runButtons[i].setForeground(fg);
            runButtons[i].setPreferredSize(new Dimension(65, 45));

            int runs = i;
            runButtons[i].addActionListener(e -> addRuns(runs, true));
            runsPanel.add(runButtons[i]);
        }
        
        // Extras Panel
        JPanel extrasPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        extrasPanel.setBackground(AppColors.PANEL_BG);
        
        wideButton = createControlButton("WD", new Color(150, 200, 255));
        noBallButton = createControlButton("NB", new Color(255, 200, 150));
        legByeButton = createControlButton("LB", new Color(220, 220, 220));
        byesButton = createControlButton("B", new Color(220, 220, 220));
        wicketButton = createControlButton("WICKET", AppColors.WICKET_RED);
        wicketButton.setForeground(Color.WHITE);

        extrasPanel.add(wideButton);
        extrasPanel.add(noBallButton);
        extrasPanel.add(legByeButton);
        extrasPanel.add(byesButton);
        extrasPanel.add(wicketButton);
        
        wideButton.addActionListener(e -> handleExtra("WD", 1, false)); 
        noBallButton.addActionListener(e -> handleExtra("NB", 1, true));
        legByeButton.addActionListener(e -> handleRunsAsExtra("LB", 1)); // Simplified to 1
        byesButton.addActionListener(e -> handleRunsAsExtra("B", 1)); // Simplified to 1
        wicketButton.addActionListener(e -> handleWicket());
        
        panel.add(runsPanel, BorderLayout.NORTH);
        panel.add(extrasPanel, BorderLayout.CENTER);
        return panel;
    }
    
    private JButton createControlButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("SansSerif", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(100, 40));
        return button;
    }
    
    // Simplified version: To add more runs, user can click multiple times (e.g., LB + 3 runs)
    private void handleRunsAsExtra(String type, int runs) {
        saveStateForUndo();
        score += runs;
        totalBalls++;
        
        String bowlerName = (String) bowlerComboBox.getSelectedItem();
        PlayerStats bowler = playerStatsMap.get(bowlerName);
        bowler.runsConceded += runs;
        bowler.ballsBowled++;
        
        String event = String.format("%d %s run(s). Score is %d/%d", runs, type, score, wickets);
        addHighlight(event);
        
        dbManager.updatePlayerStats(matchId, bowlerName, bowler);
        
        updateAllDisplays();
    }
    
    private void handleExtra(String type, int runs, boolean ballCounts) {
        saveStateForUndo();
        score += runs; 
        
        String bowlerName = (String) bowlerComboBox.getSelectedItem();
        PlayerStats bowler = playerStatsMap.get(bowlerName);
        bowler.runsConceded += runs;
        
        String event = String.format("%s extra (%d run). Score is %d/%d", type, runs, score, wickets);
        
        if (ballCounts) {
            totalBalls++;
            bowler.ballsBowled++;
            if (type.equals("NB")) {
                 String strikerName = (String) strikerComboBox.getSelectedItem();
                 PlayerStats striker = playerStatsMap.get(strikerName);
                 striker.ballsFaced++;
                 event += " (and " + runs + " run(s) to batsman)";
                 // Logic to add runs from NB (e.g., 4) would go here
                 dbManager.updatePlayerStats(matchId, strikerName, striker);
            }
        }
        
        addHighlight(event);
        dbManager.updatePlayerStats(matchId, bowlerName, bowler);
        updateAllDisplays();
    }
    
    private void handleWicket() {
        saveStateForUndo();
        String dismissal = JOptionPane.showInputDialog(this, "Wicket! Enter dismissal type (e.g., Bowled, Caught):", 
                "Wicket Details", JOptionPane.QUESTION_MESSAGE);
        
        wickets++;
        totalBalls++;
        
        String strikerName = (String) strikerComboBox.getSelectedItem();
        String bowlerName = (String) bowlerComboBox.getSelectedItem();
        PlayerStats striker = playerStatsMap.get(strikerName);
        PlayerStats bowler = playerStatsMap.get(bowlerName);
        
        bowler.wicketsTaken++;
        bowler.ballsBowled++;
        striker.ballsFaced++;
        
        String event = String.format("WICKET! %s is OUT %s. Score is %d/%d", 
                strikerName, (dismissal != null ? "(" + dismissal + ")" : ""), score, wickets);
        addHighlight(event);
        
        dbManager.updatePlayerStats(matchId, strikerName, striker);
        dbManager.updatePlayerStats(matchId, bowlerName, bowler);
        
        updateAllDisplays();
    }

    private void saveStateForUndo() {
        // Deep copy the stats map
        Map<String, PlayerStats> statsCopy = new HashMap<>();
        playerStatsMap.forEach((key, value) -> statsCopy.put(key, new PlayerStats(value)));
        
        if (!highlights.isEmpty()) {
            historyStack.push(new MatchState(score, wickets, totalBalls, isFirstInnings, 
                    highlights.get(highlights.size() - 1), statsCopy));
        }
        undoButton.setEnabled(!historyStack.isEmpty());
    }
    
    private void undoLastAction() {
        if (!historyStack.isEmpty()) {
            MatchState lastState = historyStack.pop();
            this.score = lastState.score();
            this.wickets = lastState.wickets();
            this.totalBalls = lastState.totalBalls();
            this.playerStatsMap = lastState.playerStats(); // Restore deep-copied map
            this.isFirstInnings = lastState.isFirstInnings();
            
            // Remove the highlight from DB (This is complex, so we'll just log an undo)
            // For simplicity, we will just remove from UI and in-memory list.
            highlights.remove(highlights.size() - 1); 
            highlightsTextArea.setText(String.join("\n", highlights) + "\n");
            
            // Add a special "UNDO" highlight to DB
            dbManager.addHighlight(matchId, getOverString(), "*** UNDO ACTION ***");
            // Re-persist all stats from the undone state
            playerStatsMap.forEach((name, stats) -> dbManager.updatePlayerStats(matchId, name, stats));

            updateAllDisplays();
        }
        undoButton.setEnabled(!historyStack.isEmpty());
    }
    
    private void addHighlight(String event) {
        String eventWithOver = String.format("%-6s: %s", getOverString(), event);
        highlights.add(eventWithOver);
        highlightsTextArea.append(eventWithOver + "\n");
        highlightsTextArea.setCaretPosition(highlightsTextArea.getDocument().getLength());
        
        // --- Persist Highlight ---
        dbManager.addHighlight(matchId, getOverString(), event);
    }
    
    private void updateScoreboard() {
        scoreLabel.setText(String.format("%d / %d", score, wickets));
        scoreLabel.setForeground(wickets > 5 ? AppColors.WICKET_RED.darker() : AppColors.BOLD_TEXT); 
        oversLabel.setText("Overs: " + getOverString());
        
        if (totalBalls > 0) {
            double oversForCalc = (totalBalls / 6) + ((totalBalls % 6) / 6.0);
            if (oversForCalc > 0) runRateLabel.setText("RR: " + df.format(score / oversForCalc));
        } else {
            runRateLabel.setText("RR: 0.00");
        }
        targetLabel.setText(isFirstInnings ? "Target: -" : "Target: " + target);
    }
    
    private double calculateStrikeRate(PlayerStats stats) {
        if (stats.ballsFaced == 0) return 0.0;
        return ((double) stats.runsScored / stats.ballsFaced) * 100.0;
    }
    
    private void updatePlayerStatsDisplay() {
        String strikerName = (String) strikerComboBox.getSelectedItem();
        String nonStrikerName = (String) nonStrikerComboBox.getSelectedItem();
        String bowlerName = (String) bowlerComboBox.getSelectedItem();
        
        PlayerStats strikerStats = playerStatsMap.get(strikerName);
        PlayerStats nonStrikerStats = playerStatsMap.get(nonStrikerName);
        PlayerStats bowlerStats = playerStatsMap.get(bowlerName);
        
        String strikerSR = srDF.format(calculateStrikeRate(strikerStats));
        String nonStrikerSR = srDF.format(calculateStrikeRate(nonStrikerStats));
        
        if (strikerStats != null) 
            batsman1StatsLabel.setText(String.format("%s* (STR): %d (%d) [4s:%d, 6s:%d] | SR: %s", 
                strikerName, strikerStats.runsScored, strikerStats.ballsFaced, strikerStats.fours, strikerStats.sixes, strikerSR));
        
        if (nonStrikerStats != null) 
            batsman2StatsLabel.setText(String.format("%s (N-S): %d (%d) [4s:%d, 6s:%d] | SR: %s", 
                nonStrikerName, nonStrikerStats.runsScored, nonStrikerStats.ballsFaced, nonStrikerStats.fours, nonStrikerStats.sixes, nonStrikerSR));
        
        if (bowlerStats != null) 
            bowlerStatsLabel.setText(String.format("%s: %d.%d - %d R - %d W", bowlerName, 
                bowlerStats.ballsBowled / 6, bowlerStats.ballsBowled % 6, bowlerStats.runsConceded, bowlerStats.wicketsTaken));
    }
    
    private void swapBatsmen() {
        int strikerIdx = strikerComboBox.getSelectedIndex();
        int nonStrikerIdx = nonStrikerComboBox.getSelectedIndex();
        strikerComboBox.setSelectedIndex(nonStrikerIdx);
        nonStrikerComboBox.setSelectedIndex(strikerIdx);
        updatePlayerStatsDisplay();
    }
    
    private String getOverString() { return (totalBalls / 6) + "." + (totalBalls % 6); }
    
    private void disableControls() {
        for (Component comp : ((JPanel) controlsPanel.getComponent(0)).getComponents()) comp.setEnabled(false);
        for (Component comp : ((JPanel) controlsPanel.getComponent(1)).getComponents()) comp.setEnabled(false);
        undoButton.setEnabled(false);
    }
    
    private void enableControls() {
        for (Component comp : ((JPanel) controlsPanel.getComponent(0)).getComponents()) comp.setEnabled(true);
        for (Component comp : ((JPanel) controlsPanel.getComponent(1)).getComponents()) comp.setEnabled(true);
        // undoButton is handled by its own logic
    }
    
    private void initializeTeams() {
        if (matchData.tossWinner().equals(matchData.teamAName())) {
            battingTeam = matchData.tossDecision().equals("Bat") ? matchData.teamAName() : matchData.teamBName();
            bowlingTeam = matchData.tossDecision().equals("Bat") ? matchData.teamBName() : matchData.teamAName();
        } else {
            battingTeam = matchData.tossDecision().equals("Bat") ? matchData.teamBName() : matchData.teamAName();
            bowlingTeam = matchData.tossDecision().equals("Bat") ? matchData.teamAName() : matchData.teamBName();
        }
    }
    
    private void initializePlayerStats() {
        matchData.teamAPlayers().forEach(p -> playerStatsMap.put(p, new PlayerStats()));
        matchData.teamBPlayers().forEach(p -> playerStatsMap.put(p, new PlayerStats()));
    }
}
package com.scorenexus.ui;

import com.scorenexus.main.ScoreboardManager;

import javax.swing.*;
import java.awt.*;

/**
 * The initial selection panel shown on app launch.
 * Features the app logo and match selection buttons.
 */
public class SelectionPanel extends JPanel {

    public SelectionPanel(ScoreboardManager manager) {
        setLayout(new BorderLayout(0, 50)); // Gaps
        setBackground(AppColors.BACKGROUND_LIGHT);
        setBorder(BorderFactory.createEmptyBorder(50, 150, 100, 150));

        // --- Add Logo ---
        ImageIcon logoIcon = new ImageIcon("resources/app_logo.png");
        // Scale logo to be less intrusive
        Image scaledImg = logoIcon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
        JLabel logoLabel = new JLabel(new ImageIcon(scaledImg));
        logoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        add(logoLabel, BorderLayout.CENTER);

        // --- Panel for Buttons ---
        JPanel buttonPanel = new JPanel(new GridLayout(1, 1, 30, 30)); // Only 1 button for now
        buttonPanel.setOpaque(false); // Transparent background

        JButton cricketButton = new JButton("⚾ Start Cricket Match");
        styleButton(cricketButton, AppColors.PRIMARY_BUTTON_BG);
        cricketButton.addActionListener(e -> manager.showCricketSetup());
        
        buttonPanel.add(cricketButton);
        // Add more buttons here if needed (e.g., Football)
        
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setFont(new Font("SansSerif", Font.BOLD, 24));
        button.setBackground(bgColor);
        button.setForeground(AppColors.PRIMARY_BUTTON_FG);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(bgColor.darker(), 2),
            BorderFactory.createEmptyBorder(15, 25, 15, 25)
        ));
    }
}
package com.scorenexus.ui;

import com.scorenexus.main.ScoreboardManager;
import com.scorenexus.model.MatchData;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.stream.Collectors;

/**
 * Panel for setting up all details of a new cricket match.
 */
public class CricketSetupPanel extends JPanel {
    
    private final ScoreboardManager manager;
    private JTextField teamANameField = new JTextField("Team A");
    private JTextField teamBNameField = new JTextField("Team B");
    private JComboBox<String> matchTypeBox = new JComboBox<>(new String[]{"T20", "ODI", "Test Match"});
    private JTextField totalOversField = new JTextField(); 
    private JTextField venueField = new JTextField("Local Ground");
    private JComboBox<String> tossWinnerBox;
    private JComboBox<String> tossDecisionBox = new JComboBox<>(new String[]{"Bat", "Bowl"});
    private ArrayList<JTextField> teamAPlayerFields = new ArrayList<>();
    private ArrayList<JTextField> teamBPlayerFields = new ArrayList<>();

    public CricketSetupPanel(ScoreboardManager manager) {
        this.manager = manager;
        setBackground(AppColors.BACKGROUND_LIGHT);
        setLayout(new BorderLayout(20, 20));
        
        TitledBorder mainBorder = BorderFactory.createTitledBorder("⚾ Cricket Match Setup");
        mainBorder.setTitleFont(new Font("SansSerif", Font.BOLD, 18));
        mainBorder.setTitleColor(AppColors.BOLD_TEXT);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(20, 20, 20, 20),
            mainBorder
        ));
        
        JPanel formPanel = createFormPanel();
        JPanel playersPanel = createPlayersPanel();
        
        JButton startButton = new JButton("Start Match");
        startButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        startButton.setBackground(AppColors.PRIMARY_BUTTON_BG);
        startButton.setForeground(AppColors.PRIMARY_BUTTON_FG);
        startButton.addActionListener(e -> collectDataAndStartMatch());
        
        JPanel southPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        southPanel.setBackground(AppColors.BACKGROUND_LIGHT);
        southPanel.add(startButton);

        add(formPanel, BorderLayout.NORTH);
        add(new JScrollPane(playersPanel), BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createFormPanel() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(AppColors.PANEL_BG);
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        // Row 0
        gbc.gridy = 0;
        gbc.gridx = 0; formPanel.add(new JLabel("Team A Name:"), gbc);
        gbc.gridx = 1; formPanel.add(teamANameField, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Team B Name:"), gbc);
        gbc.gridx = 3; formPanel.add(teamBNameField, gbc);

        // Row 1
        gbc.gridy = 1;
        gbc.gridx = 0; formPanel.add(new JLabel("Match Type:"), gbc);
        gbc.gridx = 1; formPanel.add(matchTypeBox, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Total Overs:"), gbc);
        gbc.gridx = 3; formPanel.add(totalOversField, gbc);

        // Row 2
        gbc.gridy = 2;
        gbc.gridx = 0; formPanel.add(new JLabel("Venue:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3; formPanel.add(venueField, gbc); // Span 3 cols
        gbc.gridwidth = 1; // Reset

        // Row 3
        gbc.gridy = 3;
        gbc.gridx = 0; formPanel.add(new JLabel("Toss Won By:"), gbc);
        gbc.gridx = 1; tossWinnerBox = new JComboBox<>(new String[]{teamANameField.getText(), teamBNameField.getText()});
        formPanel.add(tossWinnerBox, gbc);
        gbc.gridx = 2; formPanel.add(new JLabel("Decision:"), gbc);
        gbc.gridx = 3; formPanel.add(tossDecisionBox, gbc);

        totalOversField.setEditable(false);
        matchTypeBox.addActionListener(e -> updateOversBasedOnType());
        updateOversBasedOnType(); 
        
        teamANameField.addActionListener(e -> updateTossWinnerBox());
        teamBNameField.addActionListener(e -> updateTossWinnerBox());
        updateTossWinnerBox();
        return formPanel;
    }

    private JPanel createPlayersPanel() {
        JPanel playersPanel = new JPanel(new GridLayout(1, 2, 20, 0));
        playersPanel.setBackground(AppColors.BACKGROUND_LIGHT);
        playersPanel.add(createPlayerInputPanel(teamANameField.getText(), teamAPlayerFields));
        playersPanel.add(createPlayerInputPanel(teamBNameField.getText(), teamBPlayerFields));
        
        // Update panel titles when team names change
        teamANameField.addActionListener(e -> 
            ((TitledBorder) ((JPanel) playersPanel.getComponent(0)).getBorder()).setTitle(teamANameField.getText() + " Players")
        );
        teamBNameField.addActionListener(e -> 
            ((TitledBorder) ((JPanel) playersPanel.getComponent(1)).getBorder()).setTitle(teamBNameField.getText() + " Players")
        );
        
        return playersPanel;
    }

    private void updateOversBasedOnType() {
        String selectedType = (String) matchTypeBox.getSelectedItem();
        if (selectedType == null) return;
        switch (selectedType) {
            case "T20" -> totalOversField.setText("20");
            case "ODI" -> totalOversField.setText("50");
            case "Test Match" -> totalOversField.setText("90"); // Per day
            default -> totalOversField.setText("");
        }
    }

    private void updateTossWinnerBox() { 
        tossWinnerBox.setModel(new DefaultComboBoxModel<>(new String[]{teamANameField.getText(), teamBNameField.getText()})); 
    }
    
    private JPanel createPlayerInputPanel(String title, ArrayList<JTextField> playerFields) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(AppColors.PANEL_BG);
        
        TitledBorder border = BorderFactory.createTitledBorder(title + " Players");
        border.setTitleColor(AppColors.BOLD_TEXT);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(AppColors.BORDER_COLOR),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        for (int i = 1; i <= 11; i++) {
            JTextField playerField = new JTextField("Player " + i, 15);
            playerFields.add(playerField);
            JPanel playerRow = new JPanel(new BorderLayout(10, 0));
            playerRow.setBackground(AppColors.PANEL_BG);
            playerRow.add(new JLabel("Player " + i + ":"), BorderLayout.WEST);
            playerRow.add(playerField, BorderLayout.CENTER);
            panel.add(playerRow);
            panel.add(Box.createRigidArea(new Dimension(0, 5)));
        }
        return panel;
    }
    
    private void collectDataAndStartMatch() {
        try {
            int overs = Integer.parseInt(totalOversField.getText());
            MatchData data = new MatchData(
                teamANameField.getText(), teamBNameField.getText(),
                (String) matchTypeBox.getSelectedItem(), overs,
                venueField.getText(), (String) tossWinnerBox.getSelectedItem(),
                (String) tossDecisionBox.getSelectedItem(),
                teamAPlayerFields.stream().map(JTextField::getText).collect(Collectors.toCollection(ArrayList::new)),
                teamBPlayerFields.stream().map(JTextField::getText).collect(Collectors.toCollection(ArrayList::new))
            );
            manager.startCricketMatch(data);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "A valid match type must be selected.", 
                    "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
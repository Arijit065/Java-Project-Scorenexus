package com.scorenexus.ui;

import java.awt.Color;

/**
 * Defines a simple color palette for the application.
 */
public interface AppColors {
    Color PRIMARY_BUTTON_BG = new Color(50, 150, 50); // Green
    Color PRIMARY_BUTTON_FG = Color.WHITE;
    Color SECONDARY_BUTTON_BG = new Color(70, 130, 180); // Blue
    Color SECONDARY_BUTTON_FG = Color.WHITE;
    Color WICKET_RED = new Color(200, 50, 50); // Red
    Color BACKGROUND_LIGHT = new Color(240, 248, 255); // Alice Blue
    Color PANEL_BG = Color.WHITE;
    Color BOLD_TEXT = new Color(0, 51, 102); // Dark Blue
    Color GOAL_COLOR = new Color(255, 140, 0); // Orange
    Color BORDER_COLOR = new Color(200, 200, 200); // Light Gray
}
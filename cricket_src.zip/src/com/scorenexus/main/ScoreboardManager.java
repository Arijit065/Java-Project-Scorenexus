package com.scorenexus.main;

import com.scorenexus.db.DatabaseManager;
import com.scorenexus.model.MatchData;
import com.scorenexus.ui.AppColors;
import com.scorenexus.ui.CricketPanel;
import com.scorenexus.ui.CricketSetupPanel;
import com.scorenexus.ui.SelectionPanel;

import javax.swing.*;
import java.awt.*;

/**
 * The main application frame and entry point.
 * Manages the CardLayout for switching between panels.
 */
public class ScoreboardManager extends JFrame {
    
    private CardLayout cardLayout = new CardLayout();
    private JPanel mainPanel = new JPanel(cardLayout);
    private JTabbedPane tabbedPane;
    private DatabaseManager dbManager;

    public ScoreboardManager() {
        // --- Setup Nimbus L&F and Modern UI Defaults ---
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            UIManager.put("nimbusBase", AppColors.SECONDARY_BUTTON_BG);
            UIManager.put("nimbusBlueGrey", AppColors.BACKGROUND_LIGHT);
            UIManager.put("control", AppColors.PANEL_BG);
        } catch (Exception e) {
            System.out.println("Nimbus L&F not available, using default.");
        }

        // --- Initialize Database ---
        try {
            // Ensure the SQLite driver is loaded
            Class.forName("org.sqlite.JDBC"); 
            dbManager = new DatabaseManager();
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, 
                "Error: SQLite JDBC Driver not found.\nMake sure the .jar is in the 'lib' folder.", 
                "Driver Error", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }

        setTitle("ScoreNexus - Scoreboard Manager");
        // --- Set Frame Icon ---
        setIconImage(new ImageIcon("resources/app_icon.ico").getImage());
        
        setSize(1200, 850);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // --- Create Panels ---
        SelectionPanel selectionPanel = new SelectionPanel(this);
        CricketSetupPanel cricketSetupPanel = new CricketSetupPanel(this);
        
        tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("SansSerif", Font.BOLD, 14));

        // --- Add Panels to CardLayout ---
        mainPanel.add(selectionPanel, "Selection");
        mainPanel.add(cricketSetupPanel, "CricketSetup");
        mainPanel.add(tabbedPane, "App");
        
        add(mainPanel);
        setVisible(true);
    }
    
    public void showCricketSetup() {
        cardLayout.show(mainPanel, "CricketSetup");
    }

    public void startCricketMatch(MatchData data) {
        int cricketTabIndex = tabbedPane.indexOfTab("⚾ Cricket");
        if (cricketTabIndex != -1) {
            tabbedPane.remove(cricketTabIndex);
        }
        
        // Pass the DatabaseManager to the CricketPanel
        CricketPanel cricketPanel = new CricketPanel(data, dbManager);
        
        tabbedPane.insertTab("⚾ Cricket", null, cricketPanel, "Cricket Scoreboard", 0);
        tabbedPane.setSelectedIndex(0);
        cardLayout.show(mainPanel, "App");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ScoreboardManager::new);
    }
}
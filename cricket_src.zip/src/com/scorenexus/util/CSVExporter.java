package com.scorenexus.util;

import java.awt.Component;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 * Utility class for exporting data, such as highlights, to CSV.
 */
public class CSVExporter {

    /**
     * Automatically saves the highlights to a CSV file in the project's root directory.
     * The filename will include a timestamp to prevent overwriting.
     * @param parent The parent component for showing success/error messages.
     * @param highlights The list of highlight strings to export.
     */
    public static void exportHighlights(Component parent, ArrayList<String> highlights) {
        // Create a timestamped filename to avoid overwriting
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String fileName = "cricket_highlights_" + timeStamp + ".csv";
        
        // File will be saved in the directory where the java command is run
        File csvFile = new File(fileName); 
        
        try (FileWriter writer = new FileWriter(csvFile)) {
            writer.append("Event\n");
            for (String highlight : highlights) {
                // Escape double quotes by doubling them up
                String csvLine = "\"" + highlight.replace("\"", "\"\"") + "\"\n";
                writer.append(csvLine);
            }
            JOptionPane.showMessageDialog(parent, "Highlights exported successfully to:\n" + fileName, 
                    "Export Successful", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(parent, "Error exporting file: " + ex.getMessage(), 
                    "Export Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

package com.scorenexus.model;

/**
 * Class to hold individual player statistics.
 */
public class PlayerStats {
    public int runsScored = 0;
    public int ballsFaced = 0;
    public int fours = 0;
    public int sixes = 0;
    public int ballsBowled = 0;
    public int runsConceded = 0;
    public int wicketsTaken = 0;

    // Copy constructor for the Undo feature
    public PlayerStats(PlayerStats original) { 
        this.runsScored = original.runsScored;
        this.ballsFaced = original.ballsFaced;
        this.fours = original.fours;
        this.sixes = original.sixes;
        this.ballsBowled = original.ballsBowled;
        this.runsConceded = original.runsConceded;
        this.wicketsTaken = original.wicketsTaken;
    }
    
    // Default constructor
    public PlayerStats() {} 
}
package com.scorenexus.model;

import java.util.ArrayList;

/**
 * Record to hold all immutable match setup details.
 */
public record MatchData(
    String teamAName, 
    String teamBName, 
    String matchType, 
    int totalOvers,
    String venue, 
    String tossWinner, 
    String tossDecision,
    ArrayList<String> teamAPlayers, 
    ArrayList<String> teamBPlayers
) {}
package com.scorenexus.model;

import java.util.Map;

/**
 * Record to store the state of the match for the Undo feature.
 * This remains in-memory and is not persisted to the database.
 */
public record MatchState(
    int score, 
    int wickets, 
    int totalBalls, 
    boolean isFirstInnings,
    String lastHighlight, 
    Map<String, PlayerStats> playerStats
) {}
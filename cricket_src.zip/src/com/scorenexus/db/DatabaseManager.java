package com.scorenexus.db;

import com.scorenexus.model.MatchData;
import com.scorenexus.model.PlayerStats;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/**
 * Manages all JDBC database interactions for the application.
 * Uses SQLite.
 */
public class DatabaseManager {

    private static final String DB_URL = "jdbc:sqlite:scorenexus_gamedata.db";

    public DatabaseManager() {
        createTables();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL);
    }

    /**
     * Creates all necessary tables if they don't already exist.
     */
    public void createTables() {
        String createMatchesTable = """
            CREATE TABLE IF NOT EXISTS matches (
                match_id INTEGER PRIMARY KEY AUTOINCREMENT,
                team_a TEXT NOT NULL,
                team_b TEXT NOT NULL,
                match_type TEXT,
                total_overs INTEGER,
                venue TEXT,
                toss_winner TEXT,
                toss_decision TEXT,
                match_result TEXT,
                start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
            """;
        
        String createPlayersTable = """
            CREATE TABLE IF NOT EXISTS players (
                player_id INTEGER PRIMARY KEY AUTOINCREMENT,
                player_name TEXT NOT NULL UNIQUE
            );
            """;

        String createMatchStatsTable = """
            CREATE TABLE IF NOT EXISTS match_stats (
                stat_id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id INTEGER,
                player_id INTEGER,
                runs_scored INTEGER DEFAULT 0,
                balls_faced INTEGER DEFAULT 0,
                fours INTEGER DEFAULT 0,
                sixes INTEGER DEFAULT 0,
                balls_bowled INTEGER DEFAULT 0,
                runs_conceded INTEGER DEFAULT 0,
                wickets_taken INTEGER DEFAULT 0,
                FOREIGN KEY (match_id) REFERENCES matches (match_id),
                FOREIGN KEY (player_id) REFERENCES players (player_id)
            );
            """;

        String createHighlightsTable = """
            CREATE TABLE IF NOT EXISTS highlights (
                highlight_id INTEGER PRIMARY KEY AUTOINCREMENT,
                match_id INTEGER,
                over_info TEXT,
                event_description TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (match_id) REFERENCES matches (match_id)
            );
            """;

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createMatchesTable);
            stmt.execute(createPlayersTable);
            stmt.execute(createMatchStatsTable);
            stmt.execute(createHighlightsTable);
        } catch (SQLException e) {
            System.err.println("Error creating tables: " + e.getMessage());
        }
    }

    /**
     * Inserts a new match into the DB and returns its generated ID.
     * Also enrolls all players for this match.
     */
    public int createNewMatch(MatchData data) {
        String insertMatchSQL = """
            INSERT INTO matches (team_a, team_b, match_type, total_overs, venue, toss_winner, toss_decision)
            VALUES (?, ?, ?, ?, ?, ?, ?);
            """;
        int matchId = -1;

        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(insertMatchSQL, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setString(1, data.teamAName());
            pstmt.setString(2, data.teamBName());
            pstmt.setString(3, data.matchType());
            pstmt.setInt(4, data.totalOvers());
            pstmt.setString(5, data.venue());
            pstmt.setString(6, data.tossWinner());
            pstmt.setString(7, data.tossDecision());
            
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        matchId = rs.getInt(1);
                    }
                }
            }
            
            // Now enroll players for this match
            if (matchId != -1) {
                enrollPlayersForMatch(conn, matchId, data.teamAPlayers());
                enrollPlayersForMatch(conn, matchId, data.teamBPlayers());
            }

        } catch (SQLException e) {
            System.err.println("Error creating new match: " + e.getMessage());
        }
        return matchId;
    }

    /**
     * Helper to add players to the 'players' table (if new) and
     * create initial 'match_stats' entries for them.
     */
    private void enrollPlayersForMatch(Connection conn, int matchId, ArrayList<String> players) throws SQLException {
        String upsertPlayerSQL = "INSERT INTO players (player_name) VALUES (?) ON CONFLICT(player_name) DO NOTHING;";
        String getPlayerIdSQL = "SELECT player_id FROM players WHERE player_name = ?;";
        String insertStatsSQL = "INSERT INTO match_stats (match_id, player_id) VALUES (?, ?);";

        try (PreparedStatement upsertPstmt = conn.prepareStatement(upsertPlayerSQL);
             PreparedStatement selectPstmt = conn.prepareStatement(getPlayerIdSQL);
             PreparedStatement insertStatsPstmt = conn.prepareStatement(insertStatsSQL)) {

            for (String playerName : players) {
                // Add player to global player table if not present
                upsertPstmt.setString(1, playerName);
                upsertPstmt.executeUpdate();

                // Get the player's ID
                selectPstmt.setString(1, playerName);
                int playerId = -1;
                try (ResultSet rs = selectPstmt.executeQuery()) {
                    if (rs.next()) {
                        playerId = rs.getInt("player_id");
                    }
                }

                // Create a blank stats row for this player in this match
                if (playerId != -1) {
                    insertStatsPstmt.setInt(1, matchId);
                    insertStatsPstmt.setInt(2, playerId);
                    insertStatsPstmt.executeUpdate();
                }
            }
        }
    }

    /**
     * Adds a ball-by-ball highlight to the database.
     */
    public void addHighlight(int matchId, String over, String event) {
        String sql = "INSERT INTO highlights (match_id, over_info, event_description) VALUES (?, ?, ?);";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, matchId);
            pstmt.setString(2, over);
            pstmt.setString(3, event);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error adding highlight: " + e.getMessage());
        }
    }

    /**
     * Updates the persistent stats for a specific player in a specific match.
     */
    public void updatePlayerStats(int matchId, String playerName, PlayerStats stats) {
        String sql = """
            UPDATE match_stats
            SET runs_scored = ?, balls_faced = ?, fours = ?, sixes = ?,
                balls_bowled = ?, runs_conceded = ?, wickets_taken = ?
            WHERE match_id = ? AND player_id = (SELECT player_id FROM players WHERE player_name = ?);
            """;
        
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, stats.runsScored);
            pstmt.setInt(2, stats.ballsFaced);
            pstmt.setInt(3, stats.fours);
            pstmt.setInt(4, stats.sixes);
            pstmt.setInt(5, stats.ballsBowled);
            pstmt.setInt(6, stats.runsConceded);
            pstmt.setInt(7, stats.wicketsTaken);
            pstmt.setInt(8, matchId);
            pstmt.setString(9, playerName);
            
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating player stats for " + playerName + ": " + e.getMessage());
        }
    }

    /**
     * Records the final result of the match.
     */
    public void endMatch(int matchId, String result) {
        String sql = "UPDATE matches SET match_result = ? WHERE match_id = ?;";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, result);
            pstmt.setInt(2, matchId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error ending match: " + e.getMessage());
        }
    }
}